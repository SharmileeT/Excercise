﻿namespace MailContainerTest.Types
{
    public enum MailType
    {
        StandardLetter,
        LargeLetter,
        SmallParcel
    }
}
