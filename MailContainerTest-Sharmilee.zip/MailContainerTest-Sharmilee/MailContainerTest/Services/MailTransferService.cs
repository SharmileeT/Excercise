﻿using MailContainerTest.Data;
using MailContainerTest.Types;
using System.Configuration;

namespace MailContainerTest.Services
{
    public class MailTransferService : IMailTransferService
    {
        public MakeMailTransferResult MakeMailTransfer(MakeMailTransferRequest request)
        {
           

            MailContainerFactory getMailFactory = new MailContainerFactory();
            MailContainer mailContainer =getMailFactory.GetMailCOntainer(request);



            MailFactory mailFactory = new MailFactory();
            var result=mailFactory.GetResult( request, mailContainer);
            

            if (result.Success)
            {
                mailContainer.Capacity -= request.NumberOfMailItems;

                MailContainerFactory updatemailfactory = new MailContainerFactory();
                updatemailfactory.UpdateMailCOntainer(mailContainer);
            }

            return result;
        }
    }
}
