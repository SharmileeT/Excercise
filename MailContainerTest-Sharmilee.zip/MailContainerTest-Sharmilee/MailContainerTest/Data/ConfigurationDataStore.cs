﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MailContainerTest.Data
{
    public class ConfigurationDataStore
    {
        public string Get()
        {
            return ConfigurationManager.AppSettings["DataStoreType"];
        }
    }
}
