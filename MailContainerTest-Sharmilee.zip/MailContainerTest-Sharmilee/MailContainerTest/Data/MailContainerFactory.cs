﻿using MailContainerTest.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MailContainerTest.Data
{
    public class MailContainerFactory
    {
        public ConfigurationDataStore configurationDataStore { get; set; } = new ConfigurationDataStore();
        public void UpdateMailCOntainer(MailContainer mailContainer)
        {
            if (configurationDataStore.Get() == "Backup")
            {
                var mailContainerDataStore = new BackupMailContainerDataStore();
                mailContainerDataStore.UpdateMailContainer(mailContainer);

            }
            else
            {
                var mailContainerDataStore = new MailContainerDataStore();
                mailContainerDataStore.UpdateMailContainer(mailContainer);
            }
            
        }

        public MailContainer GetMailCOntainer(MakeMailTransferRequest request)
        {
            if (configurationDataStore.Get() == "Backup")
            {
                var mailContainerDataStore = new BackupMailContainerDataStore();
                return mailContainerDataStore.GetMailContainer(request.SourceMailContainerNumber);

            }
            else
            {
                var mailContainerDataStore = new MailContainerDataStore();
                return mailContainerDataStore.GetMailContainer(request.SourceMailContainerNumber);
            }
           
        }
    }
}
