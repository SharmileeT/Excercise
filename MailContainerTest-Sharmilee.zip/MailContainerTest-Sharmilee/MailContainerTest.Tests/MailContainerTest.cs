﻿using MailContainerTest.Data;
using MailContainerTest.Services;
using MailContainerTest.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace MailContainerTest.Tests
{
	public class MailContainerTest
	{
		[Fact]
		public void TestMailTransferService()
		{
			MakeMailTransferRequest newtest = new MakeMailTransferRequest();
			newtest.DestinationMailContainerNumber = "999";
			newtest.MailType = MailType.LargeLetter;
			newtest.NumberOfMailItems = 1;
			newtest.TransferDate = DateTime.Now;
			newtest.SourceMailContainerNumber = "89";

			IMailTransferService servicet = new MailTransferService();
			MakeMailTransferResult result=servicet.MakeMailTransfer(newtest);
			Assert.False(result.Success);
		}

		[Fact]
		public void TestTransferResultForAllowedMailStandardLetter()
        {
			MakeMailTransferRequest request = new MakeMailTransferRequest();
			request.DestinationMailContainerNumber = "999";
			request.MailType = MailType.LargeLetter;
			request.NumberOfMailItems = 1;
			request.TransferDate = DateTime.Now;
			request.SourceMailContainerNumber = "89";

			MailContainer container = new MailContainer() {
				AllowedMailType = AllowedMailType.StandardLetter,
				Capacity = 1,
				MailContainerNumber = "56",
				Status = MailContainerStatus.Operational
			};

			MailFactory factory = new MailFactory();
			MakeMailTransferResult result = factory.GetResult(request, container);
			Assert.False(result.Success);
		}

		[Fact]
		public void TestGetMailContainerForDatabackUp()
        {
			MailContainerFactory factoryMail = new MailContainerFactory();
			MakeMailTransferRequest request = new MakeMailTransferRequest();
			request.DestinationMailContainerNumber = "999";
			request.MailType = MailType.LargeLetter;
			request.NumberOfMailItems = 1;
			request.TransferDate = DateTime.Now;
			request.SourceMailContainerNumber = "89";
			MailContainer mailContainer=factoryMail.GetMailCOntainer(request);
			Assert.NotNull(mailContainer);	
		}
	}
}